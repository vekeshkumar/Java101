package basicsPrgms;

public class levelOnePrgms {
	
	//Get Century from the year
	public  int getCenturyFromYear(int year) {
		if(year%100 == 0) {
			year = (year/100);
		}else {
			year = (year/100)+1;
		}
		 return year;
	}
	
	//Check whether its a Palindrome or Not

	public boolean checkPalindrome(String inputString) {
		/*Step 1: get the Length of the string, form a reverse order then
		then  with original string 
		if it matches 
		palindrome 
		else 
		not a palindrome*/

		 int stringLength = inputString.length();
		 String reverse="";
		 boolean isPalindrome = false;

		 for(int i = stringLength -1; i >= 0; i--){
		   reverse += inputString.charAt(i);	
		 }
		if(inputString.equals(reverse)){
		 return isPalindrome = true;
		}

		return isPalindrome;

	}

	
	//factorial program- for loop
	public int  getFactorial1(int inputNumber) {
		int i,fact =1;
		for(i=1;i<=inputNumber;i++) {
			fact*=i;
		}
		return fact;
	}
	//factorial program while loop
	public int getFactorial2(int inputNumber) {
		int i =1, fact=1;
		while(i<=inputNumber) {
			fact*= i;
			i++;
		}
		return fact;
	}

	//factorial program using recursion
	public int getFactorialRecursion(int inputNumber) {
		if(inputNumber == 0) {
			return 1;
		}
		else {
			return (inputNumber*getFactorialRecursion(inputNumber-1));
		}
	}
	
	//find occurrence of each alphabets
	public void getWordFrequencyList() {
		String wordArray[] = {"abcdbc","abbccdd","acccdad"};
		
	}
	public static void main(String args[]) {
		
		levelOnePrgms  Obj = new levelOnePrgms();
		
		//System.out.println(Obj.getCenturyFromYear(2019));
		//System.out.println(Obj.checkPalindrome("aabaa")+"palindrome");
		//System.out.println(Obj.getFactorial1(5));
		//System.out.println(Obj.getFactorial2(5));
		/*
		 * int fact=1; fact = Obj.getFactorialRecursion(5); System.out.println(fact);
		 */
	}
	
}
